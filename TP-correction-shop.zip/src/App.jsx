import { useState } from 'react'
import {BrowserRouter, Routes, Route, Navigate} from 'react-router'
import Products from './pages/Products'
import CartPage from './pages/CartPage'
import Checkout from './pages/Checkout'
import NotFound from'./pages/NotFound'
import Layout from './components/Layout'

import './App.css'

function App() {
   // Etat du panier :[{id,name,price,image, qty }]
    const [items, setItems] =useState([]);


const addToCart = (product) => {
    //setItems([...items, product])
    setItems((prev) =>{
      const exists = prev.find((i)=> i.id === product.id);
        if(exists){
         return  prev.map( (i)=> i.id === product.id ? {...i, qty: i.qty + 1} : i )
        }

        return [...prev, {...product, qty:1}]

    })

}

const increase = (id) => {
setItems((prev) => prev.map((i)=> (i.id === id ? {...i, qty:qty+1} : i ))  );
}

const decrease = (id) => {

  setItems((prev) => prev.map((i)=> (i.id === id ? {...i, qty:qty - 1} : i ))
  .filter((i)=> i.qty>0)  );
}

const deleteCart = () => setItems([]); 

const total = items.reduce((sum, i) => sum + i.price * i.qty, 0)
const count = items.reduce((sum, i) => sum + i.qty, 0)

  return (
    
           <BrowserRouter>
            <Routes>
                         
            <Route path="/"  element ={<Layout total={total} count={count} />}>
                      <Route index element={ <Navigate to="/products" replace />} />
                      <Route  path="products" element={<Products  addToCart={addToCart}/>} />

                      <Route path="checkout"  element={<Checkout />} />

                      <Route path="cart"  element={
                        <CartPage 
                            items={items}
                            increase={increase}
                            decrease={decrease}
                            deleteCart={deleteCart}
                            total={total}
                            count ={count}
                        />
                      } />

                      <Route path="*"  element={<NotFound/>}  />  
            </Route>
            </Routes>

        </BrowserRouter>

  );
}

export default App;
