export default function CartItem ({item,increase,decrease}){

    return(

        <div className="cart-tem">
            <img src={item.image}  alt={item.name} />

            <div  className="cart-info">
                <strong> {item.name} </strong> 
                <p> {item.price}</p>

            </div>

            <div className="qty">
                <button onClick={()=> decrease(item.id)}> - </button>
                  <span> {item.qty}</span>
                <button onClick={()=> increase(item.id)}> +  </button>
            </div>

        </div>
    )
}