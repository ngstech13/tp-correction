import { NavLink, Outlet}  from 'react-router'

export default function Layout ({total,count}){

    return(

        <div>
            <header>
                <nav  className="menu">

                    <NavLink to="/products">  Products </NavLink>
                    <NavLink to="/cart">  Panier ({count}) </NavLink>

                </nav>
                <strong> Total panier : {total} </strong>
            </header>

            <main>

                <Outlet />

            </main>

        </div>
    ); 


}