import { products } from "../data/products";

export default function Products({addToCart}){

    return(
            <div>
                <h2> Products</h2>
               
                 {products.map((p,i)=>{
                    return(
                    <div key={p.id}  className="product">
                    <img src={p.image}  alt={p.name}  />
                      <div>
                          <h3> {p.name}</h3>
                          <p>  {p.price} </p>

                          <button onClick={()=>addToCart(p) }> Ajouter au panier </button>
                      </div>  
                     </div>    
                 )})}
    
            </div>


    ); 
}