import {Link }  from 'react-router'

export default function NotFound(){

    return(

          <div>
                  <h2> Erreur 404 : page introuvable !!!</h2>
                  <Link to="/products"> Retour aux produits </Link>

          </div>
    ); 
}