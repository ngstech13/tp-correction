import {Link, useNavigate } from "react-router"
import CartItem from "../components/CartItem"


export default function CartPage({items, increase,decrease,total,count,deleteCart}){
  const navigate = useNavigate()
    if(items.length === 0){
        return(
             <div>
                  <h2> Votre panier est vide </h2>
                  <Link to="/products"> Continuez vos achats !</Link>
             </div>
        );
    }

const onCancel = ()=>{
     navigate("/products");
}

     return(
            <>
                  <h2> Panier </h2>
                  
                    {items.map((item)=>{
                       <CartItem 
                          key={item.id}
                          item={item}
                          increase={increase}
                          decrease={decrease}
                       />

                    })}

               <div className="resume">
                   <h3>Total de la commande : {total} € TTC </h3>
                   {  items.map((item)=>{
                         <p key ={item.id} >
                            {item.name} {item.price} € 
                            { item.qty > 1 && `${item.qty} articles`}

                         </p>
                   })}
                 </div>  

                 <div className="actions">

                    <button onClick={()=>navigate("/checkout") }> Procéder au paiement </button>
                    <Link to="/products"> Continuez vos achats </Link>
                    <button onClick={onCancel}> Annuler</button>
                 </div>


            </>

           


              
     )



}
