import {useState} from 'react'
import {Link} from 'react-router'

export default function Checkout ({total, deleteCart, items}){
   const[paid, setPaid] = useState(false);

     if(paid){

        return(
            <div>  
                <h3> Merci pour votre commande ! </h3>

                <Link to="/products"> Retour aux produits </Link>

            </div>
        )
     }

     if( total===0){

        return(
               <div>
                    <h2> Aucun article  </h2>
                    <Link to="/products"> Retour aux produits </Link>

               </div>
        );
     }

    const onPay=()=>{
        deleteCart();
        setPaid(true); 

    }

  return(

       <div>
            <h2> Paiement </h2>
            <p> Montant à payer : <strong> {total} €TTC</strong></p>

                 <h4> Récapitulatif de la commande  </h4>
                
                 <ul>
                    { items.map( (it,i)=>{
                        <li key={it.id}> {it.name } - {it.price} </li>
                    })}
                     
                 </ul>

            <button onClick={onPay}> Payer </button>
            <Link  to="/cart"> Retour au panier </Link>
       </div>
  )
}