export const products =[
   {id:1, name:"Produit A", price:1000, image:"https://placehold.co/120x100" },
   {id:2, name:"Produit B", price:1000, image:"https://placehold.co/120x100" },
  {id:3, name:"Produit C", price:1000, image:"https://placehold.co/120x100" },

]; 